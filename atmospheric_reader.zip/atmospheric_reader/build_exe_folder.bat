@echo off
REM OPTIONAL folder build (many files, but it STARTS FASTER than the single exe): dist\AtmosphericReader\AtmosphericReader.exe
REM Prefers Python 3.11 if it has PySide6, otherwise uses "python". Only PyInstaller may get installed.
cd /d "%~dp0"
set PY=python
py -3.11 -c "import PySide6" >nul 2>&1 && set PY=py -3.11
echo Using: %PY%
%PY% -m pip show pyinstaller >nul 2>&1 || %PY% -m pip install pyinstaller || goto :err
set ICON=
if exist icon.ico set ICON=--icon icon.ico --add-data "icon.ico;."
REM --noupx: UPX-packed Qt DLLs start slower and trip antivirus.
%PY% -m PyInstaller --noconfirm --clean --windowed --noupx --name AtmosphericReader %ICON% main.py || goto :err

REM Optional: an ffmpeg.exe next to main.py is shipped too, for the automatic MP4 -> WebM wallpaper conversion.
if exist ffmpeg.exe copy /y ffmpeg.exe "dist\AtmosphericReader\" >nul

REM Trim files the app never reads (fewer/lighter files = faster first start, smaller folder):
REM  - Chromium UI-language packs except en-US and pt-BR (Chromium falls back to en-US for any other language)
REM  - Qt .qm translation files (the app installs no QTranslator)
set "D=dist\AtmosphericReader"
for /d /r "%D%" %%L in (qtwebengine_locales) do if exist "%%L" (
    for %%P in ("%%L\*.pak") do if /i not "%%~nP"=="en-US" if /i not "%%~nP"=="pt-BR" del /q "%%P"
)
for /r "%D%" %%F in (*.qm) do del /q "%%F"

echo.
echo Done:  dist\AtmosphericReader\AtmosphericReader.exe
pause
exit /b 0
:err
echo Build failed - see messages above.
pause
exit /b 1
