@echo off
REM Downloads ffmpeg (official Windows "essentials" build from gyan.dev, ~30 MB) and puts ffmpeg.exe next to main.py.
REM build_exe.bat runs this for you (with "nopause") if ffmpeg.exe is missing, and packs it INSIDE the exe.
cd /d "%~dp0"
if exist ffmpeg.exe (
    echo ffmpeg.exe is already here.
    if not "%1"=="nopause" pause
    exit /b 0
)
echo Downloading ffmpeg...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
 "$ErrorActionPreference='Stop';" ^
 "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" ^
 "$z=Join-Path $env:TEMP 'ffmpeg_dl.zip'; $d=Join-Path $env:TEMP 'ffmpeg_dl';" ^
 "Invoke-WebRequest 'https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip' -OutFile $z -UseBasicParsing;" ^
 "if(Test-Path $d){Remove-Item $d -Recurse -Force}; Expand-Archive $z $d -Force;" ^
 "$f=Get-ChildItem $d -Recurse -Filter ffmpeg.exe | Select-Object -First 1;" ^
 "Copy-Item $f.FullName '%~dp0ffmpeg.exe'; Remove-Item $z,$d -Recurse -Force" || goto :err
if not exist ffmpeg.exe goto :err
echo.
echo Done: ffmpeg.exe is now next to main.py.
if not "%1"=="nopause" pause
exit /b 0
:err
echo.
echo Download failed. Get "ffmpeg-release-essentials.zip" from https://www.gyan.dev/ffmpeg/builds/
echo and copy bin\ffmpeg.exe next to main.py by hand.
if not "%1"=="nopause" pause
exit /b 1
