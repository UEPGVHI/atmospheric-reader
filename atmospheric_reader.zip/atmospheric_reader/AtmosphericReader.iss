; Atmospheric Reader - installer script for Inno Setup 6.3 or newer (free, jrsoftware.org).
; Do not run this by hand: double-click build_installer.bat, it builds the exe if needed and then this installer.
#define AppName "Atmospheric Reader"
#define AppExe "AtmosphericReader.exe"
#define AppVersion "1.0"

[Setup]
AppId={{B7C1E0A4-5D3F-4C8E-9A52-7E1F3B6D2A90}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher={#AppName}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
UninstallDisplayName={#AppName}
UninstallDisplayIcon={app}\{#AppExe}
SetupIconFile=icon.ico
OutputDir=.
OutputBaseFilename=AtmosphericReader-Setup
Compression=lzma2/fast
SolidCompression=yes
WizardStyle=modern
; installs just for the current user by default (no administrator prompt); the wizard offers "all users" too
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; a running copy is closed (with the user's consent) so an update can replace the exe
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
Source: "{#AppExe}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "{cm:LaunchProgram,{#AppName}}"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; the unpacked video converter is ours and large: always removed with the app
Type: filesandordirs; Name: "{localappdata}\AtmosphericReader\AtmosphericReader\cache"

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
begin
  if (CurUninstallStep = usPostUninstall) and (not UninstallSilent()) then
  begin
    if MsgBox('Also delete your atmospheres, settings and the saved browser data (logins, cookies)?' + #13#10 + #13#10 +
              'Choose No to keep them for a future reinstall.', mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
    begin
      DelTree(ExpandConstant('{userappdata}\AtmosphericReader'), True, True, True);
      DelTree(ExpandConstant('{localappdata}\AtmosphericReader'), True, True, True);
    end;
  end;
end;
