# -*- mode: python ; coding: utf-8 -*-
# One-file build: Python, Qt, the web engine and the icon live inside AtmosphericReader.exe.
#
# ffmpeg is built in too, but NOT as an ordinary bundled file: everything bundled the normal way is unpacked to a
# temp folder on every start of a single-file exe, and ffmpeg is the biggest single file. Instead it is LZMA-packed
# and embedded as a Windows resource (mapped on demand, never unpacked at start). The app unpacks it once, into the
# user's cache folder, the first time a video conversion really needs it (see reader/ffmpeg_pack.py).
#   AR_FFMPEG_MODE=resource  (default)  embed as an exe resource: lazy, zero start-up cost
#   AR_FFMPEG_MODE=data                 fallback: ship the packed file as a normal data file (works everywhere,
#                                       but is unpacked with the rest at every start)
import os
import sys

sys.path.insert(0, SPECPATH)
from reader import ffmpeg_pack            # Qt-free, safe to import at build time

HERE = SPECPATH
FFMPEG = os.path.join(HERE, "ffmpeg.exe")
PACKED = os.path.join(HERE, ffmpeg_pack.PACKED_NAME)
MODE = os.environ.get("AR_FFMPEG_MODE", "resource").strip().lower()

if os.path.exists(FFMPEG):
    if not os.path.exists(PACKED) or os.path.getmtime(PACKED) < os.path.getmtime(FFMPEG):
        print("Packing ffmpeg.exe (one-off, about a minute)...")
        ffmpeg_pack.pack(FFMPEG, PACKED)
    have_ffmpeg = True
else:
    have_ffmpeg = False
    print("NOTE: ffmpeg.exe not found: this exe will have no built-in video converter.")

# Files the app never reads, left out so the exe is smaller and unpacks faster at every start:
#  - Chromium UI-language packs except en-US / pt-BR (Chromium falls back to en-US) and Qt .qm translations
#  - the Chromium DevTools resources (the app never opens DevTools)
#  - Qt modules the app does not use (it only uses Core/Gui/Widgets/Svg/Multimedia/Pdf/WebEngine)
KEEP_LOCALES = {"en-US.pak", "pt-BR.pak"}
UNUSED_QT = ("Qt63D", "Qt6Quick3D", "Qt6Charts", "Qt6DataVisualization", "Qt6Designer", "Qt6Help", "Qt6Sql",
             "Qt6Test", "Qt6Bluetooth", "Qt6Nfc", "Qt6Sensors", "Qt6SerialPort", "Qt6Scxml", "Qt6RemoteObjects",
             "Qt6Graphs", "Qt6VirtualKeyboard")


def wanted(entry):
    dest = entry[0].replace("\\", "/")
    base = dest.rsplit("/", 1)[-1]
    if "/qtwebengine_locales/" in dest or dest.startswith("qtwebengine_locales/"):
        return base in KEEP_LOCALES
    if base == "qtwebengine_devtools_resources.pak":
        return False
    if base.startswith(UNUSED_QT):
        return False
    return not dest.endswith(".qm")


datas = [("icon.ico", ".")]
if have_ffmpeg and MODE == "data":
    datas.append((PACKED, "."))

a = Analysis(
    ["main.py"],
    pathex=[],
    binaries=[],
    datas=datas,
    hiddenimports=[],
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter", "test", "lib2to3", "distutils", "setuptools", "pkg_resources", "pip", "curses",
              "turtle", "idlelib", "xmlrpc", "ftplib", "imaplib", "poplib", "smtplib"],
    noarchive=False,
)
a.binaries = [b for b in a.binaries if wanted(b)]
a.datas = [d for d in a.datas if wanted(d)]
pyz = PYZ(a.pure)

extra = {}
if have_ffmpeg and MODE != "data":
    extra["resources"] = [f"{PACKED},{ffmpeg_pack.RT_RCDATA},{ffmpeg_pack.RES_NAME},0"]   # FILE,TYPE,NAME,LANGUAGE

exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="AtmosphericReader",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,                       # UPX-packed Qt DLLs start slower and trip antivirus
    runtime_tmpdir=None,
    console=False,                   # no black console window
    icon=["icon.ico"],
    **extra,
)
