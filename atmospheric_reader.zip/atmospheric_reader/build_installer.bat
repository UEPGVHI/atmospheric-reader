@echo off
REM ONE double-click -> AtmosphericReader-Setup.exe : a normal Windows installer (wizard, shortcuts, uninstaller).
REM Needs Inno Setup 6.3+ ONCE on THIS PC (free); it is installed automatically through winget if it is missing.
cd /d "%~dp0"

if not exist AtmosphericReader.exe (
    echo AtmosphericReader.exe not found, building it first...
    call build_exe.bat nopause
    if errorlevel 1 goto :err
)

call :findiscc
if not defined ISCC (
    echo Inno Setup not found, installing it with winget...
    winget install --id JRSoftware.InnoSetup -e --silent --accept-package-agreements --accept-source-agreements
    call :findiscc
)
if not defined ISCC goto :noinno

"%ISCC%" AtmosphericReader.iss || goto :err
echo.
echo Done:  AtmosphericReader-Setup.exe   (this folder)
echo Give that single file to anyone: it installs the app with shortcuts and an uninstaller.
if not "%1"=="nopause" pause
exit /b 0

:findiscc
set ISCC=
for %%D in ("%ProgramFiles(x86)%\Inno Setup 6" "%ProgramFiles%\Inno Setup 6" "%LOCALAPPDATA%\Programs\Inno Setup 6") do (
    if exist "%%~D\ISCC.exe" set "ISCC=%%~D\ISCC.exe"
)
exit /b 0

:noinno
echo Inno Setup could not be installed automatically.
echo Download and install it from https://jrsoftware.org/isdl.php and run this file again.
if not "%1"=="nopause" pause
exit /b 1
:err
echo Failed - see messages above.
if not "%1"=="nopause" pause
exit /b 1
