@echo off
REM ONE double-click -> AtmosphericReader.exe : a single file. Whoever runs it needs NO Python and nothing else.
REM (Building needs Python once on THIS PC; nothing is re-downloaded if it is already installed.)
cd /d "%~dp0"
set PY=python
py -3.11 -c "import PySide6" >nul 2>&1 && set PY=py -3.11
%PY% --version >nul 2>&1
if errorlevel 1 goto :nopython

REM libraries: installed only if missing
%PY% -c "import PySide6" >nul 2>&1 || %PY% -m pip install -r requirements.txt || goto :err
%PY% -m PyInstaller --version >nul 2>&1 || %PY% -m pip install pyinstaller || goto :err

REM ffmpeg (for the automatic MP4 -> WebM wallpaper conversion): downloaded only if not already here.
REM It is packed INTO the exe as a resource and only unpacked the first time a conversion needs it.
if not exist ffmpeg.exe call get_ffmpeg.bat nopause

set AR_FFMPEG_MODE=resource
%PY% -m PyInstaller --noconfirm --clean AtmosphericReader.spec
if errorlevel 1 (
    echo.
    echo Build with the embedded-resource ffmpeg failed, retrying with ffmpeg as a plain bundled file...
    set AR_FFMPEG_MODE=data
    %PY% -m PyInstaller --noconfirm --clean AtmosphericReader.spec || goto :err
)
copy /y "dist\AtmosphericReader.exe" "AtmosphericReader.exe" >nul

echo.
echo Done:  AtmosphericReader.exe   (this folder; a copy is also in dist\)
echo Move that single file anywhere you like. You can delete everything else.
if not "%1"=="nopause" pause
exit /b 0
:nopython
echo Python was not found. Install Python 3.10 - 3.12 ONCE from python.org (tick "Add python.exe to PATH"),
echo then run this file again. The finished exe does not need Python.
if not "%1"=="nopause" pause
exit /b 1
:err
echo Build failed - see messages above.
if not "%1"=="nopause" pause
exit /b 1
