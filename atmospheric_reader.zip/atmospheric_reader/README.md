# Atmospheric Document & Web Reader

Read live web pages, PDFs, .txt and .md files over a custom wallpaper with looping background music.
Presets bundle **content + background image + music** under one name.

## Run
    python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
    pip install -r requirements.txt
    python main.py

## Layout
    main.py            entry point
    reader/presets.py  Preset dataclass, JSON store, asset import
    reader/audio.py    QMediaPlayer wrapper (loop, volume, cross-fade)
    reader/viewers.py  WebViewer (WebEngine), TextViewer (txt/md)
    reader/pdfview.py  PdfViewer (QtPdf), loaded when the first PDF is opened
    reader/videoview.py VideoViewer, loaded when the first video is opened
    reader/ffmpeg_pack.py  built-in ffmpeg: packed at build time, unpacked on first use
    reader/dialogs.py  create/edit preset dialog
    reader/window.py   background canvas, sidebar, wiring

## Where data lives
`QStandardPaths.AppDataLocation/AtmosphericReader/` (Linux `~/.local/share/AtmosphericReader`,
Windows `%APPDATA%\AtmosphericReader`, macOS `~/Library/Application Support/AtmosphericReader`):
- `presets.json` - presets + settings (volume, panel opacity, last preset)
- `assets/` - background images and audio, copied here when a preset is saved
URLs are stored as-is; PDF/text documents are referenced in place (edits show up live).

## Build a Windows .exe (single file)
Double-click `build_exe.bat`. Result: **`AtmosphericReader.exe`**, one file with Python, Qt, the web engine, the icon and
ffmpeg (downloaded automatically if missing) all inside. The person running it needs nothing installed.
- ffmpeg is built in but costs nothing at start-up: it is LZMA-packed into the exe as a Windows resource (not unpacked
  with the rest on every launch). The first time a video conversion needs it, it is unpacked once to
  `%LOCALAPPDATA%\AtmosphericReader\AtmosphericReader\cache\bin` and reused from then on. If embedding as a resource
  ever fails, `build_exe.bat` retries by shipping it as a plain bundled file (same behaviour, but unpacked at every start).
- Building needs Python once on the PC that builds; libraries are installed only if missing, never re-downloaded.
- The single exe unpacks itself to a temp folder on every start, so it opens a few seconds slower than a folder build.
  If that bothers you, `build_exe_folder.bat` makes the faster-starting folder version (`dist\AtmosphericReader\`).
- Your presets live in `%APPDATA%`, not in the exe, so you can move or replace the exe freely.

## Videos & content-less presets
- Content can be a local video (.mp4 .mkv .webm .mov .avi .m4v .wmv) or a direct link to one.
  Playback uses the OS codecs (Windows Media Foundation), and the background music ducks while a video plays.
- The content field is optional: a preset with only a name + wallpaper/music applies them instantly
  to whatever page, PDF, text or video is already open.

## Video wallpapers
A preset's Background can be a video (.mp4 .webm .mkv .mov .avi .m4v .wmv). It loops silently behind the app
(the preset's music is separate). Web pages get it too: frames are streamed into the page at ~25 fps (a still frame is
the fallback on sites whose security policy blocks it). Videos over 200 MB are referenced in place instead of being copied into the assets folder.

## Icon & ordering
`icon.ico` is used for the window, the taskbar and the built .exe (bundled automatically by `build_exe.bat`).
Presets can be re-ordered by dragging them in the sidebar; the order is saved.

## Which Python?
PySide6 6.9 (tested) supports Python 3.9-3.13. If `python` on your PATH is 3.14, run with the older one:
`py -3.11 main.py`  (or the full path to its python.exe).

## Lowest-CPU video wallpapers
In web pages the app first lets the browser engine play the wallpaper itself (hardware decoding, almost no CPU).
This works for formats Chromium can play, mainly **WebM (VP9/AV1)**. If it can't, the app falls back to streaming
decoded frames (heavier on the CPU). The sidebar shows which mode is active. To convert an mp4:

    ffmpeg -i input.mp4 -c:v libvpx-vp9 -b:v 0 -crf 30 -an output.webm

## Automatic WebM conversion
Choosing a non-WebM video as a preset's Background asks for a destination folder (it remembers the last one), then converts it to VP9 WebM (progress dialog, cancellable,
same resolution and frame rate, audio dropped since wallpapers are silent). The file stays in the folder you chose (the preset references it there, so don't move it) and
the original is left untouched. It needs `ffmpeg`: the exe built by `build_exe.bat` already contains it. When running from the sources, put `ffmpeg.exe` next to `main.py` or have it on PATH (`get_ffmpeg.bat` downloads it for you). An `ffmpeg.exe` placed next to the exe always takes priority over the built-in one. Without ffmpeg the original is used and the app streams frames as before.

## Folders and the Startup slot
The sidebar groups atmospheres into folders (UI only: nothing is created on your PC, it is saved in `presets.json`).
- **New folder** button (or right-click empty space). Click a folder to show / hide its atmospheres; it remembers open/closed.
- Drag an atmosphere onto a folder (or between its rows) to file it; right-click → *Move to folder* does the same.
  Right-click a folder to rename, move up/down or delete it (its atmospheres are kept).
- **Startup** is the pinned slot at the very top: the atmosphere in it opens first every time the app starts.
  Right-click an atmosphere → *Set as startup atmosphere*, or drag it onto the slot; drag it out (or *Remove from Startup*) to clear it.

## Icons
All in-app icons are small SVGs in `reader/icons.py` (silver gradient, rendered by QtSvg at the exact pixel size, so
they stay sharp at any display scaling). The app icon source is `icon.svg`; `icon.ico` holds it pre-rendered at
16-256 px (`icon_previous.ico` / `icon_original.ico` are the older versions).

Fullscreen: the toolbar button and **F11** do the same thing (and **Esc** leaves it). Zen mode (hide panels) has its own
eye button and **F10**.

## Glass UI, scroll rail & extras
- Frosted-glass panels (blurred wallpaper + tint), a glass bezel around the content, and a right-hand **scroll rail**
  (drag, page up/down, top/bottom, auto-scroll with speed slider) that works for web pages, PDFs and text.
- **Resume reading**: the scroll position of each PDF/text file/web page is remembered.
- **Zen mode** (F10 / Esc): only wallpaper + content. Preset **search**, right-click **Edit / Duplicate / Delete**.
- Less CPU: the window's own video copy is paused when the browser plays it and covers the window (zen mode),
  when minimised, and optionally when the app is unfocused.

## Start-up and speed notes
- The window appears first; the startup atmosphere (wallpaper decode, music, page load) loads right after it.
- The PDF viewer, video viewer, video-wallpaper player and the local video server are only created / imported when first used.
- The single-file exe unpacks everything to a temp folder on each start, so its start time follows its size: ffmpeg stays out
  of that unpacking (see above) and unused Qt modules, DevTools resources and Chromium language packs are left out.

## Update the chapter on exit
When you close the app while reading a web page that is different from the active atmosphere's saved address, it asks
**"Update the chapter before leaving?"** (Yes / No). Yes saves the page you are on as that atmosphere's URL (only the URL
changes: name, wallpaper, music and folder stay as they are), so it reopens at your chapter. It does not ask when the
atmosphere has no web address, when something other than a web page is open, or when the address is already the same.
Right-click an atmosphere that has a web address → **Update chapter to the current page** does the same at any time. It is
enabled for the atmosphere you are reading (right-click the one that is open) when the page differs from its saved address.

## PDF bookmarks
PDF atmospheres have a one-page bookmark, saved in `presets.json` with the atmosphere.
- Closing the app while reading its PDF on a page other than the saved one asks **"Save your page before leaving?"** (Yes / No).
- Right-click the open PDF atmosphere → **Save bookmark here (page N)**, or **Remove bookmark**.
- An atmosphere with a bookmark always reopens at that page, replacing the automatic reading position. Hover it in the
  sidebar to see the page. Changing the atmosphere's PDF in Edit clears the bookmark. A PDF opened another way (address bar,
  drag and drop) is never bookmarked into the atmosphere.

## Update the Startup atmosphere on exit
If you close the app while inside an atmosphere that has no web address (wallpaper and music only) and you are reading a web
page, it asks **"Update the Startup atmosphere “name” before leaving?"** Yes saves the page as the web address of the atmosphere
in the Startup slot (only that URL changes). It only asks when the Startup atmosphere has a web address that differs from the page.

## Installer (Setup wizard)
Double-click `build_installer.bat`. Result: **`AtmosphericReader-Setup.exe`**, a normal Windows installer: Next / Install / Finish,
choose the folder, optional desktop shortcut, Start-menu entry, "Launch" at the end and an entry in Settings → Apps to uninstall.
It installs for the current user by default (no administrator prompt; the wizard also offers all users) and closes a running copy
before updating. Uninstalling removes the app and the unpacked video converter, and asks whether to also delete your atmospheres,
settings and saved browser data (default: keep).
- It builds `AtmosphericReader.exe` first if it isn't there, and installs Inno Setup (free, needed only on the PC that builds the
  installer) through winget if it is missing. Setup is not code-signed, so Windows SmartScreen may show "unknown publisher" once.
- `AtmosphericReader.iss` holds the wizard's settings (name, version, shortcuts) if you want to change them.
